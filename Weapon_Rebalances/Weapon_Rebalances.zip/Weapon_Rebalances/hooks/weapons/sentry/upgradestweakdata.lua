Hooks:PostHook(UpgradesTweakData, "init", "WR UpgradesTweakData init", function(self)
	self.sentry_gun_base_ammo = 600
end)