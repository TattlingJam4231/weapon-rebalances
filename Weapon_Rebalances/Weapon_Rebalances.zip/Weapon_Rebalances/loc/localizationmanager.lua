Hooks:Add("LocalizationManagerPostInit", "Weapon Rebalances Localization", function(loc)
	LocalizationManager:add_localized_strings({
		["menu_dance_instructor_desc"] = 	"BASIC: ##2 points##\n" ..
											"Your pistol magazine sizes are increased by ##5## bullets.\n\n" ..
											"ACE: ##4 points##\n" ..
											"You reload all pistols ##50%## faster.",

		["menu_expert_handling_desc"] = 	"BASIC: ##3 points##\n" ..
											"Each successful pistol hit gives you a 10% increased accuracy bonus for ##10## seconds and can stack ##4## times.\n\n" ..
											"ACE: ##6 points##\n" ..
											"You gain a ##50%## increased rate of fire with pistols.",

		["menu_sniper_graze_damage_desc"] = "BASIC: ##4 points##\n" ..
											"Snipers that hit their target deal ##20%## of the damage dealt in a ##1m## radius around the bullet trajectory.\n\n" ..
											"When fired in single shot mode, Assault Rifles that hit their target deal ##20%## of the damage dealt in a ##2.75m## radius around the bullet impact.\n\n" ..
											"ACE: ##8 points##\n" ..
											"If a bullet would headshot someone, the graze skill will deal ##100%## of the damage dealt instead of ##20%##.",

		["menu_speedy_reload_beta_desc"] = 	"BASIC: ##3 points##\n" ..
											"Increases your reload speed with SMGs, Assault Rifles and Sniper Rifles by ##35%##\n\n" ..
											"ACE: ##6 points##\n" ..
											"Any killing headshot will increase your reload speed by ##100%## for ##4## seconds. " ..
											"Can only be triggerd by SMGs, Assault Rifles and Sniper Rifles fired in single shot fire mode.",

		["menu_shotgun_cqb_beta_desc"] = 	"BASIC: ##2 points##\n" ..
											"You reload Shotguns ##15%## faster.\n\n" ..
											"ACE: ##4 points##\n" ..
											"You reload Shotguns an additional ##35%## faster. You gain a ##125%## increased steel sight zoom speed when using Shotguns."
	})
end)